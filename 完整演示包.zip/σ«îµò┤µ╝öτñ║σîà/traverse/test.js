/**
 * Created by yishan on 17/4/22.
 */
var path = require('path');
var fs = require('fs');

//1.指定文件夹的绝对路径
var abslot_path = path.resolve('../files')
//2.json的名称
var filename = 'test1'

//封装打印--console.log写的次数太多烦得很
function log(msg) {
    var time = Date.now()
    console.log(msg)
}


//json-母版   是母版 不是模板 - -!
var json = {
        id: 0,
        label: 'files',//这个是根目录的名称  根据传入的路径改变
        sup: '',//父级的路径
        children: []//如果有子目录的话 就要有这个数组
}
    ;
//记录父级目录
//var sup_mark = path.resolve('../files');
//获取文件列表
function getDir_list(abslot_path,spath) {
    abslot_path = path.resolve(abslot_path);
    abslot_path = path.normalize(abslot_path);
    //指定保存路径
    //记录当前文件夹的路径
    fs.readdir(abslot_path, function (err, files) {

        //遍历判断文件类型
        files.forEach(function (val, item) {
            //stat 要绝对路径 将val转成绝对路径
            //拼接路径  fp就是文件夹/文件的绝对路径
            var fp = path.join(abslot_path, val)
            //父级目录
            var sup_path = path.resolve(fp, '../');
            log('getDir_list保存参数===',spath)
            fs.stat(fp, function (err, stat) {

                if (stat.isDirectory()) {
                    //创建json
                    var data = {
                        label: val,
                        sup: sup_path,
                        children: []
                    };
                    //log('当前文件是---' + val+'父文件'+sup_path+'item===='+item);
                    //判断父级文件
                    //添加到json数组中

                    parent_dir(json, data,spath);
                    //递归
                    getDir_list(fp);


                }
                if (stat.isFile()) {
                    //log('当前文件是---' + val+'父文件'+sup_path+'item===='+item);
                    //创建目录文件
                    var data = {
                        label: val,
                        sup:sup_path
                    };

                    //data.sup = path.normalize(data.sup)
                    parent_dir(json, data,spath)
                }

            });
        });


    });

}


/**
 * 查找父级 并将子集添加到父级数组
 * @param parent  目录集合文件 总的json
 * @param child   当前的子级 json对象
 * @param index   子级的id
 */
function parent_dir(parent, child,spath) {

    //先判断第一个节点是否是父节点
    var len = parent.label.length;
    var text = child.sup.substr(-len);
    if (parent.label == text) {
        parent.children.push(child);
    } else {
        //查找 id-1的目录
        var arr = parent.children;
        //遍历数组
        log("parent_dir保存参数====="+spath)
        search(arr, child,spath)

    }


}
/**
 *  查找传入节点的父节点 并加入到父节点的数组中
 * @param arr   总json
 * @param child  传入创建的json子节点
 */
function search(arr, child,spath) {
    //val是每个json节点
    arr.forEach(function (val) {
        //1.先判断当前遍历的节点是否是文件夹--是否有children属性
        if ('children' in val) {
            //取得文件夹的名称
            var Dname = val.label;
            var child_sup = child.sup.substr(-Dname.length);

            //判断child json的父级
            if (Dname == child_sup) {
                //判断是否已经存入

                //val.children.add(child);
                val.children.push(child);
                log('filename=='+filename)
            } else {
                //当前节点不是传入child的父节点  继续向下遍历
                search(val.children, child);
                //写入文件
                log('filename=='+filename)

            }

        }
    })
    log("search保存参数====="+spath);

}
//将json写入到文件
function writefile(fp, data) {
    if(!fp){
        //throw new Error('没有指定保存路径')
    }
    data = JSON.stringify(data);
    fs.writeFile(fp, data, {flag: 'w+'}, function (err) {
        log('开始保存文件')
        if (err == null) {
            log('写入成功成功')
        }else {
            log(err)
        }
    })
}






/**
 *
 * @param fp 指定遍历的
 * @param fname
 * @param root
 */
module.exports = function (fp) {
    if(fp==null){
        throw new Error('没有指定遍历的目录地址')
    }
    //如果传入的是一个数组 数组中 元素是指定的文件路径

    if(fp instanceof Array){
        log('传入的是数组');
        log('---------------------')
        fp.forEach(function (val,key) {
            //对路径切片
            var sep = path.sep;//获取当前系统的文件分隔符
            var fp = val.split(sep);
            var fname = fp[fp.length-1];
            json.label = fname
            //拼接输出json的路径
            var save_path = './'+fname+'.json';
            //拿到产品第一级目录去遍历
            filename = save_path
            log('遍历路径='+val);
            log('保存路径='+filename);
            getDir_list(val,save_path);
        })
    }else {

        //路径切片
        //先取得当前系统的 文件分隔符

        log('单个路径');
        var sep = path.sep;
        //第一层级的文件名称
        var fpath = fp.split(sep);
        json.label = fpath[fpath.length-1];

        var filepath = '../test/'+fpath[fpath.length-1]+'.json';

        ////filename 是全局的  文件写入路径
        filename = filepath;
        log('传入的参数'+filename)
        getDir_list(fp,filepath);
        log('----------------------------------------------------------------------------1')
    }

    log('----------------------------------------------------------------------------2')
    writefile(filename,json)

};
