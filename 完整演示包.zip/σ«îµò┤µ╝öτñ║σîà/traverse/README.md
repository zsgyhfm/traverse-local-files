# traverse-local-files
使用nodejs遍历本地文件夹及其子目录输出一个json文件并写入到本地文件中
- 使用方式 参见  example
